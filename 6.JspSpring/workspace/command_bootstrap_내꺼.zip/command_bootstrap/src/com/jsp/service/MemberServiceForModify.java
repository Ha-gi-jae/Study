package com.jsp.service;

import com.jsp.dto.MemberVO;

public interface MemberServiceForModify extends MemberService {
	
	void modify(MemberVO member) throws Exception;
	
	void remove(String id) throws Exception;
	
	void enabled(MemberVO member) throws Exception;
	
	void enabled(String id, int enabled) throws Exception;
}
